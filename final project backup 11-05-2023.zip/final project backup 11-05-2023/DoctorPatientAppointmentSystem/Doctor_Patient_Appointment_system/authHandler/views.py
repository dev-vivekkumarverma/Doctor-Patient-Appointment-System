from django.shortcuts import render,redirect
from django.contrib.auth.models import User,Group
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login,logout,authenticate
from DoctorApp.models import DoctorDetails

from django.http import HttpResponse
from utility_modules.emailtest import *

# Create your views here.


def userRegistration(request):
    try:
        if request.method=="GET":
            return render(request=request,template_name='user_registration.html')
        elif request.method=="POST":
            print(request.POST)
            password=request.POST.get("password","")
            conform_password=request.POST.get("conform_password","")
            if password==conform_password:
                username=request.POST.get("username","")
                email=request.POST.get("email","")
                group=request.POST.get("group","patient")
                if all([password,conform_password,username,email,group]):
                    newUser=User.objects.create_user(username=username,password=password,email=email)
                    if group=="doctor":
                        newUser.is_active=False
                    else:
                        newUser.is_active=True
                    newUser.save()
                    group_object,_=Group.objects.get_or_create(name=group)
                    newUser.groups.add(group_object)
                    if group=='doctor' and newUser.is_active is False:
                        message=f"""
Dear {username},
    Your registration has been successfull...
    activation code : 567232
    This is your account activation link... 
    http://localhost:8000/users/activate/{newUser.pk}
                    """
                        subject="DPA System varification success"
                        # email_thread=threading.Thread(group=None,target=send_email,args=[email,subject,message])
                        # email_thread.start()
                        send_email(email,subject=subject,body=message)
                    elif group=='patient':
                        # make opt based activation system for patient user
                        pass
                    print("registrations successful...")
                    return redirect(to='user_login_view')
                else:
                    raise Exception("some fields are missing")
            else:
                raise Exception("Password and conform_password do not match..")
    except Exception as e:
        return  HttpResponse(str(e))



def userLogin(request):
    if request.method=="GET":
        return render(request=request,template_name="user_login.html")
    elif request.method=="POST":
        username=request.POST.get("username","")
        password=request.POST.get("password","")
        print("username:",username)
        print("password:",password)
        if all([username,password]):
            authenticatedUser=authenticate(username=username,password=password)
            print(authenticatedUser)
            if authenticatedUser != None:
                if authenticatedUser.is_active is True:
                    login(request=request,user=authenticatedUser)
                    if request.user.groups.filter(name="patient").exists():
                        return redirect(to="patient_home_page_view")
                    elif request.user.groups.filter(name="doctor").exists():
                        return redirect(to="all_appointments_view")
                    else: 
                        return HttpResponse('login successfull...')
                else:
                    return HttpResponse(f"activate your account... \ncheck your email for activation Link...\n check mail from doctorpatientappointmentsystem@gmail.com\nThank you...")
            else:
                raise Exception("authentication failed...")
        else:
            raise Exception("Some fields missing..")
        
@login_required(login_url="user_login_view")
def userLogout(request):
    user=request.user.username
    logout(request=request)
    message=f"{user} has been successfully Logged out. "
    return render(request=request,template_name="user_logout.html",context={"message":message})



def account_activation(request,userId:int):
    try:
        user=User.objects.get(pk=userId)
        if user is not None:
            if user.is_active is False:
                user.is_active=True
                user.save()
                message=f" Congratualations your DPA-System account has been successfully activated ! "
                subject="no-reply"
                # mail_thread=threading.Thread(group=None,target=send_email,args=[user.email,subject,message])
                # mail_thread.start()
                send_email(user.email,subject=subject,body=message)
                return redirect(to="user_login_view")
            else:
                raise Exception("Already actived account can not be re-activated !")
        else:
            raise Exception("Invalid User...")
    except Exception as e:
        return render(request=request,template_name="message.html",context={"message":str(e)})
            
