import smtplib
from email.message import EmailMessage
import os
# import dotenv
import ssl
import threading
# print(".env Loading")
# dotenv.load_dotenv(".env")
# print(".env loaded...")

email_sender=os.getenv("EMAIL_SENDER")
email_password=os.getenv("EMAIL_PASSWORD")
# # email_receiver="vivekkumarverma332@gmail.com"
# email_receiver=["parasharbharali21@gmail.com","uddiptagogoi2000@gmail.com","vivek.verma@techvariable.com"]


# subject="testing email system form DPA-System"
# body="""
#     This is a test email from Doctor-Patient-Appointment-System.
#     If you receive this mail... Please reply to as "Working...".

#     Thank You have a good day...:)

# """

def send_mail_through_threads(func):
    def inner_func(*args, **kwargs):
        mail_thread=threading.Thread(group=None,target=func,args=args,kwargs=kwargs)
        mail_thread.start()
    return inner_func

@send_mail_through_threads
def send_email(email_receiver,subject="",body=""):
    try:
        em= EmailMessage()
        em["From"]=email_sender
        em["To"]=email_receiver
        em["Subject"]=subject
        em.set_content(body)

        # print("creating... ssl context")
        context=ssl.create_default_context()
        # print("ssl context, created...")
        with smtplib.SMTP_SSL(host="smtp.gmail.com", port=465,context=context) as smtp:
            # print("trying to login...")
            smtp.login(email_sender,email_password)
            # print('loging successful...')
            # print("sending your email...")
            smtp.sendmail(email_sender,email_receiver,em.as_string())
            # print("email sent successfully...\n to {}".format(email_receiver))
        return "success"
    except Exception as e:
        return str(e)
    
