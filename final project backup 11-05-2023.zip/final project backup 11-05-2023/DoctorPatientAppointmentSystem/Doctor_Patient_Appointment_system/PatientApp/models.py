from django.db import models
from django.contrib.auth.models import User
# Create your models here.


class UserProfilePicture(models.Model):
    user=models.ForeignKey(User,on_delete=models.DO_NOTHING)
    profile_picture=models.ImageField(upload_to="User_Profile_Picture/",max_length=100,null=True)

class MedicalRecords(models.Model):
    user=models.ForeignKey(User, on_delete=models.CASCADE,related_name="user")
    file_description=models.CharField(max_length=500,null=True, blank=True)
    file=models.FileField(upload_to="Medical_Report_Files/", max_length=100)

