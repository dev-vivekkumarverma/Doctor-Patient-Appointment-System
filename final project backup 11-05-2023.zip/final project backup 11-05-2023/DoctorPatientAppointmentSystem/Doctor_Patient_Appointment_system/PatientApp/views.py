from django.shortcuts import render,redirect
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from django.contrib.auth.models import User,Group
from .models import UserProfilePicture, MedicalRecords
from DoctorApp.models import DoctorDetails
# Create your views here.

@login_required(login_url="user_login_view")
def home_page(request):
    print("test")
    try:
        all_doctors=DoctorDetails.objects.select_related().all() 
        profile_picture=UserProfilePicture.objects.get(user=request.user)
        return render(request=request,template_name="patient_home_page.html",context={"profile_picture":profile_picture,"doctors":all_doctors})
    except Exception as e:
        profile_picture=None
        profile_picture=UserProfilePicture.objects.get(user=request.user)
        return render(request=request,template_name="patient_home_page.html",context={"profile_picture":profile_picture})

@login_required(login_url="user_login_view")
def profile(request):
    medical_records=MedicalRecords.objects.all().filter(user=request.user)
    try:
        profile_picture=UserProfilePicture.objects.get(user=request.user)
        # medical_records=MedicalRecords.objects.all().filter(user=request.user)
        return render(request=request,template_name="patient_profile.html",context={"profile_picture":profile_picture,"medical_records":medical_records})
    except Exception as e:
        if str(e)=="UserProfilePicture matching query does not exist.":
            profile_picture=None
        return render(request=request,template_name="patient_profile.html",context={"profile_picture":profile_picture,"medical_records":medical_records})

@login_required(login_url="user_login_view")
def upload_profile_picture(request):
    try:
        if request.method=="POST":
            user=request.user
            profile_picture=request.FILES.get("profile_picture","")
            if profile_picture == "":
                if user.groups.filter(name="patient").exists():
                    return redirect(to="patient_profile_view")
                elif user.groups.filter(name="doctor").exists():
                    return redirect(to="doctor_self_profile_view")
                elif user.groups.filter(name="admin").exists():
                    return redirect(to="admin")
            else:
                newprofilepicture,_=UserProfilePicture.objects.get_or_create(user=user)
                newprofilepicture.profile_picture=profile_picture
                newprofilepicture.save()
                if user.groups.filter(name="patient").exists():
                    return redirect(to="patient_profile_view")
                elif user.groups.filter(name="doctor").exists():
                    return redirect(to="doctor_self_profile_view")
                elif user.groups.filter(name="admin").exists():
                    return redirect(to="admin")

        elif request.method=="GET":
            if request.user.groups.filter(name="patient").exists():
                return render(request=request,template_name="profile_edit_page.html")
            elif request.user.groups.filter(name="doctor").exists():
                return render(request=request,template_name="doctor_edit_profile_picture.html")
    except Exception as e:
        return render(request=request, template_name="message.html", context={"message":str(e)})
    
@login_required(login_url="user_login_view")
def upload_medical_records(request):
    try:
        patient=request.user
        user_profile=UserProfilePicture.objects.get(user=patient)
        if request.method=="GET":
            patient=request.user
            patient_medical_records=MedicalRecords.objects.all().filter(user=patient)
            return render(request=request,template_name="patient_medical_record_update.html",context={"medical_records":patient_medical_records,"profile_picture":user_profile})
        elif request.method=="POST":
            patient=request.user
            file_description=request.POST.get("file_description","")
            medical_record_files=request.FILES.getlist("files")
            for record in medical_record_files:
                new_medical_record=MedicalRecords()
                new_medical_record.user=patient
                new_medical_record.file=record
                new_medical_record.file_description=file_description
                new_medical_record.save()
            
            return redirect(to="upload_medical_record_view")

    except Exception as e:
        return render(request=request,template_name="message.html",context={"message":str(e)})