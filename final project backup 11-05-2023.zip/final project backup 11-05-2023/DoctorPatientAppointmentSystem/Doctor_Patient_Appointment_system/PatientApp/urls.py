from django.urls import path,include
from .views import profile,home_page,upload_profile_picture,upload_medical_records

urlpatterns = [
    path("",home_page,name="patient_home_page_view"),
    path("profile/",profile,name="patient_profile_view"),
    path("profile_picture/",upload_profile_picture,name="upload_profile_picture_view"),
    path("medical_record/",upload_medical_records,name="upload_medical_record_view"),
]
