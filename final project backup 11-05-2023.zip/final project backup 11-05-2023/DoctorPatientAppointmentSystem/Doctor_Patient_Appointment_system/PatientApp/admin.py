from django.contrib import admin
from .models import UserProfilePicture,MedicalRecords
# Register your models here.

admin.site.register(UserProfilePicture)
admin.site.register(MedicalRecords)