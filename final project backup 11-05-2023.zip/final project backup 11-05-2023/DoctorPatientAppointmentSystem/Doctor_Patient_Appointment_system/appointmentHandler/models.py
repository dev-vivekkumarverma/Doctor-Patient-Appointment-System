from django.db import models
from django.urls import reverse
from django.contrib.auth.models import User
from django.utils import timezone
# Create your models here.


class Appointment(models.Model):
    doctor=models.ForeignKey(User,on_delete=models.DO_NOTHING,related_name="doctor")
    patient=models.ForeignKey(User,on_delete=models.DO_NOTHING,related_name="patient")
    date_time=models.DateTimeField(null=True,blank=True)
    reason=models.CharField(max_length=500,default="checkup")
    comments=models.TextField(null=True)
    created_on=models.DateTimeField(auto_now_add=True)
    is_confirm=models.BooleanField(default=False,null=True)
    is_canceled=models.BooleanField(default=False,null=True)
    is_completed=models.BooleanField(default=False,null=True)
    def get_absolute_url(self):
        return reverse("appointment_by_id_view", args=[self.pk])
    
    

