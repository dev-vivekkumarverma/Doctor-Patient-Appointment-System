from django.shortcuts import render,redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User,Group
from .models import Appointment
from PatientApp.models import UserProfilePicture, MedicalRecords
from django.http import HttpResponse
from django.utils import timezone
from utility_modules.emailtest import *
# Create your views here.


@login_required(login_url="user_login_view")
def all_appointments(request):
    user_profile=UserProfilePicture.objects.get(user=request.user)
    allAppointmentObject=Appointment.objects.select_related().all().filter(is_completed=False,is_canceled=False)
    return render(request=request, template_name="doctor_home_page.html",context={"appointments":allAppointmentObject,"profile_picture":user_profile})


@login_required(login_url="user_login_view")
def create_new_appointment(request,doctorId:int):
    try:
        if request.method=="POST":
            doctorGroup=Group.objects.get(name='doctor')
            doctorObject=User.objects.get(pk=doctorId,groups=doctorGroup)
            patient=request.user
            date_time=request.POST.get("date_time","")
            reason=request.POST.get("reason","")
            comment=request.POST.get("comment","")
            if all([doctorObject,patient,date_time]):
                appointmentObject=Appointment()
                appointmentObject.doctor=doctorObject
                appointmentObject.date_time=date_time
                appointmentObject.patient=patient
                if reason is not "":
                    appointmentObject.reason=reason
                if comment is not "":
                    appointmentObject.comments=comment
                appointmentObject.save()
                datetime=date_time.split("T")
                subject="Appointment Request Sent"
                message=f""" Dear {patient.username},
                
Your appointment request with Dr. {doctorObject.username} on {datetime[0]} at {datetime[1]} have been send successfully.

We will soon inform you about the coformation status.
Keep checking your registered email.

Thank You.
                """
                message1="your appointment request have been successfully sent...\n check your email for details."
                send_email(patient.email,subject=subject,body=message)
                return render(request=request,template_name="message.html",context={"message":message1})
            else:
                raise Exception("Some important fields are missing...")
        elif request.method=="GET":
            return render(request=request,template_name="new_appointment.html",context={"doctorId":doctorId})
    except Exception as e:
        return render(request=request, template_name="message.html",context={"message":str(e)})

@login_required(login_url="user_login_view")
def appointment_by_id(request,appointmentId:int):
    try:
        if request.method=="GET":
            appointmentObject=Appointment.objects.select_related().get(id=appointmentId)
            patient=appointmentObject.patient
            patient_profile_picture=UserProfilePicture.objects.get(user=patient)
            doctor_profile=UserProfilePicture.objects.get(user=request.user)
            all_medical_files=MedicalRecords.objects.all().filter(user=patient)
            print(all_medical_files)
            return render(request=request,template_name="appointment_details.html",context={"appointment":appointmentObject,"medical_files":all_medical_files,"profile_picture":doctor_profile,"patient_profile_picture":patient_profile_picture})
    except Exception as e:
        return render(request=request,template_name="message.html",context={"message":str(e)})
    

@login_required(login_url="user_login_view")
def confirm_appointment(request,appointmentId):
    try:
        if request.method=='POST' and request.user.groups.filter(name="doctor").exists():
            appointment=Appointment.objects.get(id=appointmentId, doctor=request.user)
            if appointment.is_confirm is False and appointment.is_canceled is False and appointment.is_completed is False:
                appointment.is_confirm=True
                appointment.save()
                subject="Appoinment Confirmed"
                message=f"""
Hey { appointment.patient.username }, 

Your appointment with Dr. { request.user.username } on {appointment.date_time} is confermed !

Thank you for the patience.
                """
                send_email(appointment.patient.email,subject=subject,body=message)
                return redirect(to="all_appointments_view")
            else:
                raise Exception("Either this appointment is completed or have been canceled before ...")
        else:
            raise Exception("Method Not allowed..")    
    except Exception as e:
        return render(request=request,template_name="message.html",context={"message":str(e)})
        
