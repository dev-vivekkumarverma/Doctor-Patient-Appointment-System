from django.shortcuts import render,redirect
from .models import DoctorDetails
from PatientApp.models import UserProfilePicture
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from utility_modules.emailtest import *
# Create your views here.

@login_required(login_url="user_login_view")
def all_doctors(request):
    user=request.user
    user_profile=UserProfilePicture.objects.get(user=user)
    all_doctors=DoctorDetails.objects.select_related().all()
    return render(request=request,template_name="all_doctors.html",context={"doctors":all_doctors,"profile_picture":user_profile})

@login_required(login_url="user_login_view")
def doctor_detail_by_id(request,doctorId:int):
    try:
        patient=request.user
        user_profile=UserProfilePicture.objects.select_related().get(user=patient)
        doctor=User.objects.get(id=doctorId)
        doctorProfile=UserProfilePicture.objects.get(user=doctor)
        doctor_Details=DoctorDetails.objects.select_related().get(profile=doctorProfile)
        return render(request=request,template_name="doctor_detail_view_page.html",context={"doctor":doctor_Details,"profile_picture":user_profile})
    except Exception as e:
        return render(request=request,template_name="message.html",context={"message":str(e)})
    
@login_required(login_url="user_login_view")
def doctor_self_detail(request):
    try:
        if request.method=="GET":
            doctor=request.user
            doctor_profile=UserProfilePicture.objects.get(user=doctor)
            doctor_details=DoctorDetails.objects.select_related().get(profile=doctor_profile)
            return render(request=request,template_name="doctor_profile_details.html",context={"doctor":doctor_details,"profile_picture":doctor_profile})
        elif request.method=="POST":
            pass
    except Exception as e:
        return render(request=request,template_name="message.html",context={"message":str(e)})
    

@login_required(login_url="user_login_view")
def doctor_self_details_update(request):
    try:
        if request.method=="GET":
            doctor=request.user
            doctor_profile=UserProfilePicture.objects.get(user=doctor)
            doctor_details=DoctorDetails.objects.select_related().get(profile=doctor_profile)
            return render(request=request,template_name="doctor_details_edit_page.html",context={"doctor":doctor_details,"profile_picture":doctor_profile})
        elif request.method=="POST":
            doctor=request.user
            old_email=request.user.email
            email=old_email
            doctor_profile=UserProfilePicture.objects.get(user=doctor)
            doctor_details=DoctorDetails.objects.select_related().get(profile=doctor_profile)
            # new data
            new_specialization_area=request.POST.get("specialization_area","")
            new_specialization=request.POST.get("specialization","")
            new_available_from_time=request.POST.get("available_from_time","")
            new_available_till_time=request.POST.get("available_till_time","")
            new_phone_number=request.POST.get("phone_number","")
            new_email=request.POST.get("email","")
            new_location_details=request.POST.get("location_details","")
            new_is_available=request.POST.get("is_available","")
            #let's check the chnages and save then one by one
            doctor_details.location_details=new_location_details
            doctor_details.specialization=new_specialization
            doctor_details.specialization_area=new_specialization_area
            change_message=""
            if new_is_available == 'true':
                new_is_available=True
            else:
                new_is_available=False
            if doctor_details.is_available!=new_is_available:
                doctor_details.is_available=new_is_available
                change_message+="* Your availability status have been changed."
            doctor_details.phone_number=new_phone_number
            if new_available_from_time !="":
                doctor_details.available_from_time=new_available_from_time
                change_message+=f"* Your start visiting time have been changed to {new_available_from_time}."
            if new_available_till_time !="":
                doctor_details.available_till_time=new_available_till_time
                change_message+=f"* Your end visiting time have been changed to {new_available_till_time}."
            doctor_details.save()
            if old_email !=new_email:
                doctor.email=new_email
                doctor.save()
                email=new_email
                change_message+=f"* Your email has been changed from {old_email} to {new_email}."
            subject="Profile Details Changed"    
            message="your profile changes have been saved successfully. following changes have been made:-\n"+change_message
            send_email(email_receiver=email,subject=subject,body=message)
            return redirect(to="doctor_self_profile_view")

    except Exception as e:
        return render(request=request,template_name="message.html",context={"message":str(e)})
    
