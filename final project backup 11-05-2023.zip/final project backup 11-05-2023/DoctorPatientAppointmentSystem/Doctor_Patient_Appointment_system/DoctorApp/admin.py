from django.contrib import admin
from .models import DoctorDetails
# ,DoctorLocation
# Register your models here.

admin.site.register(DoctorDetails)
# admin.site.register(DoctorLocation)