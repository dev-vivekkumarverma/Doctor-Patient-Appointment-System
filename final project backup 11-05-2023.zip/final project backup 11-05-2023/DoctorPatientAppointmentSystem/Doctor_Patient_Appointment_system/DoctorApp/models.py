from django.db import models
from django.contrib.auth.models import User
from django.urls import reverse
from PatientApp.models import UserProfilePicture
# Create your models here.
# Gender_choics=(("male","male"),("female","female"),("others","others"))

class DoctorDetails(models.Model):
    profile=models.ForeignKey(UserProfilePicture,on_delete=models.DO_NOTHING)
    # gender=models.CharField(choices=Gender_choics, default="male")
    specialization_area=models.CharField(max_length=300, default="general",blank=True)
    specialization=models.CharField(max_length=300,blank=True,null=True)
    location_details=models.CharField(max_length=300)
    phone_number=models.CharField(max_length=16, null=False,unique=True)
    is_varified_phone=models.BooleanField(default=False)
    available_from_time=models.TimeField()
    available_till_time=models.TimeField()
    is_available=models.BooleanField(default=True)

    def get_absolute_url(self):
        return reverse("doctor_details_by_id_view", kwargs={"doctorId": self.profile.user.pk})
    

    
# class DoctorLocation(models.Model):
#     doctor=models.ForeignKey(User,on_delete=models.DO_NOTHING)
#     place=models.CharField(max_length=400)
#     available_from_time=models.TimeField()
#     available_till_time=models.TimeField()
#     def __str__(self) -> str:
#         return self.place
    

